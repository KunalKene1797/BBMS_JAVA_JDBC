create function xpath(text, xml) returns xml[]
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.xpath($1, $2, '{}'::pg_catalog.text[])
$$;
